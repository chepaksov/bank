#!/bin/bash
psql -U bank bank-app -c 'CREATE EXTENSION pg_stat_statements;'
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE USER test WITH PASSWORD 'test';
    ALTER USER test WITH SUPERUSER;
    CREATE USER "user" WITH PASSWORD 'user';
    ALTER USER "user" WITH SUPERUSER;
EOSQL
echo "shared_preload_libraries = 'pg_stat_statements'" >>  /var/lib/postgresql/data/postgresql.conf
echo "pg_stat_statements.max = 10000" >>  /var/lib/postgresql/data/postgresql.conf
echo "pg_stat_statements.track = all" >>  /var/lib/postgresql/data/postgresql.conf
