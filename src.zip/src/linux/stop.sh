#!/bin/bash
docker-compose -p bank stop