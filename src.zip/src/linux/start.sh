#!/bin/bash
docker-compose -p bank up --build -d
docker attach --sig-proxy=false test-system