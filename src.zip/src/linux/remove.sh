#!/bin/bash
docker-compose -p bank down
docker rmi bank_postgres
docker rmi bank_test-system